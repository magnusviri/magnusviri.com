/*
This code is MIT licensed, see http://www.opensource.org/licenses/mit-license.php
*/

#include "gideros.h"
#include "lua.h"
#include "lauxlib.h"

static const char KEY_OBJECTS = ' ';

static const char* KEYBOARD_WILL_SHOW = "keyboardWillShow";
static const char* KEYBOARD_WILL_HIDE = "keyboardWillHide";
static const char* KEY_PRESSED = "keyPressed";

static void stackDump (lua_State *L) {
	int i;
	int top = lua_gettop(L);
	for (i = 1; i <= top; i++) {  /* repeat for each level */
		int t = lua_type(L, i);
		switch (t) {

		case LUA_TSTRING:  /* strings */
			printf("`%s'", lua_tostring(L, i));
			break;
    
		case LUA_TBOOLEAN:  /* booleans */
			printf(lua_toboolean(L, i) ? "true" : "false");
			break;
    
		case LUA_TNUMBER:  /* numbers */
			printf("%g", lua_tonumber(L, i));
			break;
    
		default:  /* other values */
			printf("%s", lua_typename(L, t));
    			break;

		}
		printf("  ");  /* put a separator */
	}
	printf("\n");  /* end the listing */
}

static void dispatchEvent(lua_State* L, const char* type,
						  BOOL keyboardWillShow,
						  BOOL keyboardWillHide,
			  NSString* text)
{
	lua_pushlightuserdata(L, (void *)&KEY_OBJECTS);
	lua_rawget(L, LUA_REGISTRYINDEX);
	
	lua_rawgeti(L, -1, 1);

	if (lua_isnil(L, -1))
	{
		lua_pop(L, 2);
		return;
	}
	
	lua_getfield(L, -1, "dispatchEvent");
	
	lua_pushvalue(L, -2);

	lua_getglobal(L, "Event");
	lua_getfield(L, -1, "new");
	lua_remove(L, -2);
	lua_pushstring(L, type);
	lua_call(L, 1, 1);	

	if ( keyboardWillShow ) {
		lua_pushinteger(L, 1);
		lua_setfield(L, -2, KEYBOARD_WILL_SHOW);
	} else if ( keyboardWillHide ) {
		lua_pushinteger(L, 1);
		lua_setfield(L, -2, KEYBOARD_WILL_HIDE);
	} else if ( text ) {
		lua_pushstring(L, [text UTF8String]);
		lua_setfield(L, -2, KEY_PRESSED);
	}
	if (lua_pcall(L, 2, 0, 0) != 0) {
		g_error(L, lua_tostring(L, -1));
	} else {
	}
	lua_pop(L, 2);
}

#import <UIKit/UIKit.h>
@interface InputView : UIView <UIKeyInput> {
	lua_State* L;
	BOOL _active;
}
@property (nonatomic, assign) BOOL active;
- (void)didEnterBackground;
- (void)didBecomeActive;
@end
@implementation InputView
- (id)initWithLuaState:(lua_State *)theL {
	self = [super initWithFrame:CGRectMake(0, 0, 0, 0)];
	if (self) {
		L = theL; 
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didEnterBackground) name:UIApplicationDidEnterBackgroundNotification object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didBecomeActive) name:UIApplicationDidBecomeActiveNotification object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];


		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(resignFirstResponder) name:@"UIKeyboardDidShowNotification" object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(becomeFirstResponder) name:@"UIKeyboardEmptyDelegateNotification" object:nil];

	}
	return self;
}
- (void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidEnterBackgroundNotification object:nil];
	[[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
	[[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
	[super dealloc];
}

// Testing
-(BOOL)becomeFirstResponder {
//	iCadeUsed = 1;
	return [super becomeFirstResponder];
}

-(BOOL)resignFirstResponder {
//	iCadeUsed = 0;
	return [super resignFirstResponder];
}




// Accessors
@synthesize active=_active;
- (void)setActive:(BOOL)value {
	if (_active == value) return;
	_active = value;
	if (_active) {
		[self becomeFirstResponder];
	} else {
		[self resignFirstResponder];
	}
}
// UIView Override
- (BOOL)canBecomeFirstResponder { 
    return TRUE; 
}
// Notifications
- (void)didEnterBackground {
	if (self.active)
		[self resignFirstResponder];
}
- (void)didBecomeActive {
	if (self.active)
		[self becomeFirstResponder];
}
- (void)keyboardWillShow:(NSNotification *)aNotification {
	dispatchEvent(L, KEYBOARD_WILL_SHOW, TRUE, FALSE, nil);
}
- (void)keyboardWillHide:(NSNotification *)aNotification {
	dispatchEvent(L, KEYBOARD_WILL_HIDE, FALSE, TRUE, nil);
}
// KeyInput Delegate Methods
- (BOOL)hasText {
	return FALSE;
}
- (void)insertText:(NSString *)text {
	dispatchEvent(L, KEY_PRESSED, FALSE, FALSE, text);
}
- (void)deleteBackward {
    dispatchEvent(L, KEY_PRESSED, FALSE, FALSE, @"\b");
}
@end

class KeyInput : public GEventDispatcherProxy
{
public:
	KeyInput(lua_State* L) : L(L)
	{
		input = [[InputView alloc] initWithLuaState:L];
		UIViewController* controller = g_getRootViewController();
		[controller.view addSubview:input];
	}
	~KeyInput()
	{
		[input release];
	}
	BOOL active()
	{
		return [input active];
	}
	void setActive(BOOL state)
	{
		[input setActive:state];
	}
private:
	lua_State* L;
	InputView* input;
};

static int destruct(lua_State* L)
{
	void* ptr = *(void**)lua_touserdata(L, 1);
	GReferenced* object = static_cast<GReferenced*>(ptr);
	KeyInput* keyinput = static_cast<KeyInput*>(object->proxy());
	
	keyinput->unref();
	
	return 0;
}
static KeyInput* getInstance(lua_State* L, int index)
{
	GReferenced* object = static_cast<GReferenced*>(g_getInstance(L, "KeyInput", index));
	KeyInput* keyinput = static_cast<KeyInput*>(object->proxy());
	
	return keyinput;
}
static int active(lua_State* L)
{
	KeyInput* keyinput = getInstance(L, 1);
	lua_pushboolean(L, keyinput->active());
	return 1;
}
static int setActive(lua_State* L)
{
	KeyInput* keyinput = getInstance(L, 1); 
	bool state = lua_toboolean(L, 2);
	keyinput->setActive(state);
	return 0;
}
static int loader(lua_State* L)
{
	const luaL_Reg functionlist[] = {
		{"active", active},
		{"setActive", setActive},
		{NULL, NULL},
	};

	lua_getglobal(L, "Event");
	lua_pushstring(L, KEYBOARD_WILL_SHOW);
	lua_setfield(L, -2, "KEYBOARD_WILL_SHOW");
	lua_pushstring(L, KEYBOARD_WILL_HIDE);
	lua_setfield(L, -2, "KEYBOARD_WILL_HIDE");
	lua_pushstring(L, KEY_PRESSED);
	lua_setfield(L, -2, "KEY_PRESSED");
	lua_pop(L, 1);

	g_createClass(L, "KeyInput", "EventDispatcher", NULL, destruct, functionlist);
	lua_pushlightuserdata(L, (void *)&KEY_OBJECTS);
	lua_newtable(L);                  // create a table
	lua_pushliteral(L, "v");
	lua_setfield(L, -2, "__mode");    // set as weak-value table
	lua_pushvalue(L, -1);             // duplicate table
	lua_setmetatable(L, -2);          // set itself as metatable
	lua_rawset(L, LUA_REGISTRYINDEX);	
	
	KeyInput* keyinput = new KeyInput(L);
	g_pushInstance(L, "KeyInput", keyinput->object());

	lua_pushlightuserdata(L, (void *)&KEY_OBJECTS);
	lua_rawget(L, LUA_REGISTRYINDEX);
	lua_pushvalue(L, -2);
	lua_rawseti(L, -2, 1);
	lua_pop(L, 1);	

	lua_pushvalue(L, -1);
	lua_setglobal(L, "keyinput");

	return 1;
}

static void g_initializePlugin(lua_State* L)
{
	lua_getglobal(L, "package");
	lua_getfield(L, -1, "preload");
	
	lua_pushcfunction(L, loader);
	lua_setfield(L, -2, "keyinput");
	
	lua_pop(L, 2);	
}

static void g_deinitializePlugin(lua_State *L)
{

}

REGISTER_PLUGIN("KeyInput", "1.0")

