ICADE = {
	-- ====================================================================================== --
	KEYPRESSED_EVENT = "keyPressed",
	-- ====================================================================================== --
	STATE_NONE = 14, -- nothing happen on button
	STATE_BEGIN = 15, -- button is touched
	STATE_DOWN = 16, -- button is touched
	STATE_END = 17, -- button is released
	-- ====================================================================================== --
	BUTTON1_EVENT = "iCadeB1E", -- default TNT Virtual button1 pad event name
	BUTTON2_EVENT = "iCadeB2E", -- default TNT Virtual button2 pad event name
	BUTTON3_EVENT = "iCadeB3E", -- default TNT Virtual button3 pad event name
	BUTTON4_EVENT = "iCadeB4E", -- default TNT Virtual button4 pad event name
	BUTTON5_EVENT = "iCadeB5E", -- default TNT Virtual button4 pad event name
	BUTTON6_EVENT = "iCadeB6E", -- default TNT Virtual button4 pad event name
	BUTTON7_EVENT = "iCadeB7E", -- default TNT Virtual button4 pad event name
	BUTTON8_EVENT = "iCadeB8E", -- default TNT Virtual button4 pad event name
	LEFTPAD_EVENT = "iCadeLE", -- default TNT Virtual left pad event name
	-- ====================================================================================== --
}

require "keyinput"

iCade = Core.class(EventDispatcher)
function iCade:init()
	self.keyinput = keyinput
	self.keys = {
		-- first number is the index, second number is a bit mask 
		-- (positive is down, negative is up)
		w={1,1}, d={2,2}, x={3,4}, a={4,8},
		e={1,-1}, c={2,-2}, z={3,-4}, q={4,-8},
		y={5,1}, h={6,2}, u={7,4}, j={8,8},
		i={9,16}, k={10,32}, o={11,64}, l={12,128},
		t={5,-1}, r={6,-2}, f={7,-4}, n={8,-8},
		m={9,-16}, p={10,-32}, g={11,-64}, v={12,-128},
	}
	self.joystickLookups = {
		-- index is the bitmask of the joy direction
		-- first number is angle, second number is power
		["0"]={0,0},
		["1"]={6,1}, ["3"]={7,1}, ["2"]={0,1}, ["6"]={1,1},
		["4"]={2,1}, ["12"]={3,1}, ["8"]={4,1}, ["9"]={5,1}
	}
--	--	9	1	3		225	270	315
--	--	8	0	2		180		0
--	--	12	4	6		135	90	45
	self.button1_Event = Event.new(ICADE.BUTTON1_EVENT)
	self.button2_Event = Event.new(ICADE.BUTTON2_EVENT)
	self.button3_Event = Event.new(ICADE.BUTTON3_EVENT)
	self.button4_Event = Event.new(ICADE.BUTTON4_EVENT)
	self.button5_Event = Event.new(ICADE.BUTTON5_EVENT)
	self.button6_Event = Event.new(ICADE.BUTTON6_EVENT)
	self.button7_Event = Event.new(ICADE.BUTTON7_EVENT)
	self.button8_Event = Event.new(ICADE.BUTTON8_EVENT)
	self.leftPad_Event = Event.new(ICADE.LEFTPAD_EVENT)
	self:clearPadButtonStatus()
	self.leftPad_Event.data = { selected = false, power = 0, angle = 0, state = ICADE.STATE_NONE }
	self:reset()
end
function iCade:reset()
	self.lastChange = {}
	self.joystickMask = 0
	self.joystickButtonsPressed = { 0,0,0,0 }
	self.buttonsMask = 0
	self.buttonsPressed = { 0,0,0,0,0,0,0,0 }
end
function iCade:clearPadButtonStatus()
	self.button1_Event.data = { selected = false, state = PAD.STATE_NONE }
	self.button2_Event.data = { selected = false, state = PAD.STATE_NONE }
	self.button3_Event.data = { selected = false, state = PAD.STATE_NONE }
	self.button4_Event.data = { selected = false, state = PAD.STATE_NONE }
	self.button5_Event.data = { selected = false, state = PAD.STATE_NONE }
	self.button6_Event.data = { selected = false, state = PAD.STATE_NONE }
	self.button7_Event.data = { selected = false, state = PAD.STATE_NONE }
	self.button8_Event.data = { selected = false, state = PAD.STATE_NONE }
end
function iCade:onKeyPressed(event)
	local key = event.keyPressed
	local currentKey = self.keys[key]
	if currentKey ~= nil then
		local index = currentKey[1]
		local mask = currentKey[2]
		local upDown = ( mask > 0 ) and 1 or 0
		local state = ( mask > 0 ) and ICADE.STATE_BEGIN or ICADE.STATE_END
		self.lastChange = {index, upDown}
		if index < 5 then
			-- Joystick
			self.joystickButtonsPressed[index] = upDown
			self.joystickMask = self.joystickMask + mask
			local info = self.joystickLookups[tostring(self.joystickMask)]
			if info == nil then
				io.write( "Joystick error, resetting.\n" )
				self:reset()
			else
				if self.joystickMask > 0 then
					-- Joystick pressed
					self.leftPad_Event.data.selected = true
					self.leftPad_Event.data.state = PAD.STATE_DOWN
					self.leftPad_Event.data.angle = info[1]
					self.leftPad_Event.data.power = info[2]
				else
					self.leftPad_Event.state = ICADE.STATE_END
					self.leftPad_Event.data.selected = false
					self.leftPad_Event.data.power = 0
					self:dispatchEvent(self.leftPad_Event)
				end
			end
		else
			-- Button
			self.buttonsPressed[index-4] = upDown
			self.buttonsMask = self.buttonsMask + mask
			if index == 5 then
				self.button1_Event.data.selected = true
				self.button1_Event.data.state = state
				self:dispatchEvent(self.button1_Event)
				self:clearPadButtonStatus()
			elseif index == 6 then
				self.button2_Event.data.selected = true
				self.button2_Event.data.state = state
				self:dispatchEvent(self.button2_Event)
				self:clearPadButtonStatus()
			elseif index == 7 then
				self.button3_Event.data.selected = true
				self.button3_Event.data.state = state
				self:dispatchEvent(self.button3_Event)
				self:clearPadButtonStatus()
			elseif index == 8 then
				self.button4_Event.data.selected = true
				self.button4_Event.data.state = state
				self:dispatchEvent(self.button4_Event)
				self:clearPadButtonStatus()
			elseif index == 9 then
				self.button5_Event.data.selected = true
				self.button5_Event.data.state = state
				self:dispatchEvent(self.button5_Event)
				self:clearPadButtonStatus()
			elseif index == 10 then
				self.button6_Event.data.selected = true
				self.button6_Event.data.state = state
				self:dispatchEvent(self.button6_Event)
				self:clearPadButtonStatus()
			elseif index == 11 then
				self.button7_Event.data.selected = true
				self.button7_Event.data.state = state
				self:dispatchEvent(self.button7_Event)
				self:clearPadButtonStatus()
			elseif index == 12 then
				self.button8_Event.data.selected = true
				self.button8_Event.data.state = state
				self:dispatchEvent(self.button8_Event)
				self:clearPadButtonStatus()
			end
		end
		return 1
	else
		return 0
	end
end
function iCade:onKeyboardWillShow(event)
	-- turn off iCade support
--	keyinput:setActive(false)
	keyboardShown = "yes"
end
function iCade:onKeyboardWillHide(event)
	-- Ask if it's an iCade
	-- This isn't good enough
--	keyinput:setActive(true)
	keyboardShown = "no"
end

---------------------------------------
-- dispatch pad Event on EnterFrames --
---------------------------------------
function iCade:onEnterFrame(Event)
	if self.leftPad_Event.data.selected then
		self.leftPad_Event.data.deltaTime = Event.deltaTime
		self:dispatchEvent(self.leftPad_Event)
		self.leftPad_Event.data.buttonJoyState = ICADE.STATE_NONE
	end

	for k = 1, 8 do -- check buttons
		if self.buttonsPressed[k] == 1 then
			if k == 1 then
				self.button1_Event.data.selected = true
				self.button1_Event.data.state = ICADE.STATE_DOWN
				self:dispatchEvent(self.button1_Event)
				self:clearPadButtonStatus()
			elseif k == 2 then
				self.button2_Event.data.selected = true
				self.button2_Event.data.state = ICADE.STATE_DOWN
				self:dispatchEvent(self.button2_Event)
				self:clearPadButtonStatus()
			elseif k == 3 then
				self.button3_Event.data.selected = true
				self.button3_Event.data.state = ICADE.STATE_DOWN
				self:dispatchEvent(self.button3_Event)
				self:clearPadButtonStatus()
			elseif k == 4 then
				self.button4_Event.data.selected = true
				self.button4_Event.data.state = ICADE.STATE_DOWN
				self:dispatchEvent(self.button4_Event)
				self:clearPadButtonStatus()
			elseif k == 5 then
				self.button5_Event.data.selected = true
				self.button5_Event.data.state = ICADE.STATE_DOWN
				self:dispatchEvent(self.button5_Event)
				self:clearPadButtonStatus()
			elseif k == 6 then
				self.button6_Event.data.selected = true
				self.button6_Event.data.state = ICADE.STATE_DOWN
				self:dispatchEvent(self.button6_Event)
				self:clearPadButtonStatus()
			elseif k == 7 then
				self.button7_Event.data.selected = true
				self.button7_Event.data.state = ICADE.STATE_DOWN
				self:dispatchEvent(self.button7_Event)
				self:clearPadButtonStatus()
			elseif k == 8 then
				self.button8_Event.data.selected = true
				self.button8_Event.data.state = ICADE.STATE_DOWN
				self:dispatchEvent(self.button8_Event)
				self:clearPadButtonStatus()
			end
			--break -- exit from for loop ...
		end
	end
end

----------------------
-- stop iCade --
----------------------
function iCade:stop()
	keyinput:removeEventListener("keyPressed", self.onKeyPressed, self)
	keyinput:setActive(false)
	stage:removeEventListener(Event.ENTER_FRAME, self.onEnterFrame, self)
end

-----------------------
-- start iCade --
-----------------------
function iCade:start()
	keyinput:addEventListener("keyPressed", self.onKeyPressed, self)
	keyinput:setActive(true)
	stage:addEventListener(Event.ENTER_FRAME, self.onEnterFrame, self)
end

----------------------
-- free virtual pad --
----------------------
function iCade:free()
	self:stop()
	self.button1_Event = nil
	self.button2_Event = nil
	self.button3_Event = nil
	self.button4_Event = nil
	self.button5_Event = nil
	self.button6_Event = nil
	self.button7_Event = nil
	self.button8_Event = nil
	self.leftPad_Event = nil
end

